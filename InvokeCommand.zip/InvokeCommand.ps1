Configuration SecureCommand {
    Node "localhost" {
        Script DoWork {
            GetScript = { return @{ Result = "noop" } }
            SetScript = {
                hostname
                whoami
            }
            TestScript = { return $false }
        }
    }
}
SecureCommand
