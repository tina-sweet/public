Configuration SecureCommand {
    param (
        [PSCredential] $UserAccount
    )

    Node "localhost" {
        Script DoWork {
            GetScript = { return @{ Result = "noop" } }
            SetScript = {
                try {
                   whoami
                } catch {
                    # silently ignore if DSC source doesn't exist
                }
            }
            TestScript = { return $false }
        }
    }
}
SecureCommand -UserAccount $UserAccount
