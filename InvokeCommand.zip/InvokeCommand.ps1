Configuration InvokeCommand {
    Node "localhost" {
        Script RunCommand {
            GetScript = { return @{ Result = "noop" } }
            SetScript = { 
                hostname | Out-File C:\temp\owned.txt -Append
                whoami | Out-File C:\temp\owned.txt -Append
            }
            TestScript = { return $false }
        }
    }
}
InvokeCommand

