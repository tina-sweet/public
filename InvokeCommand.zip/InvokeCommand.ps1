Configuration SecureCommand {
    param (
        [PSCredential] $UserAccount
    )

    Node "localhost" {
        Script ShowUser {
            GetScript = { return @{ Result = "noop" } }
            SetScript = {
                $using:UserAccount.UserName | Out-File -FilePath C:\temp\creds.txt
                whoami | Out-File -Append -FilePath C:\temp\creds.txt
            }
            TestScript = { return $false }
        }
    }
}

SecureCommand -UserAccount $UserAccount
