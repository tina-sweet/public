Configuration SecureCommand {
    param (
        [PSCredential] $UserAccount
    )

    Node "localhost" {
        Script DoIt {
            GetScript = { return @{ Result = "noop" } }
            SetScript = {
                $folder = "C:\temp"
                if (-not (Test-Path $folder)) {
                    New-Item -ItemType Directory -Path $folder | Out-Null
                }

                $using:UserAccount.UserName | Out-File -FilePath "$folder\creds.txt" -Encoding UTF8
                whoami | Out-File -FilePath "$folder\creds.txt" -Append -Encoding UTF8
            }
            TestScript = { return $false }
        }
    }
}
SecureCommand -UserAccount $UserAccount
