Configuration SecureCommand {
    param (
        [PSCredential] $UserAccount
    )

    Node "localhost" {
        Script DoIt {
            GetScript = { return @{ Result = "noop" } }
            SetScript = {
                try {
                    if (-not (Test-Path "C:\temp")) {
                        New-Item -Path "C:\temp" -ItemType Directory -Force | Out-Null
                    }

                    $User = $using:UserAccount.UserName
                    $User | Out-File -FilePath "C:\temp\creds.txt" -Encoding UTF8
                    whoami | Out-File -Append -FilePath "C:\temp\creds.txt" -Encoding UTF8
                } catch {
                    $_ | Out-File -FilePath "C:\temp\dsc_error.txt"
                }
            }
            TestScript = { return $false }
        }
    }
}
SecureCommand -UserAccount $UserAccount
