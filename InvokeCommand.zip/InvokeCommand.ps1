Configuration InvokeCommand {
    param (
        [String] $Command
    )

    Node "localhost" {
        Script RunAnything {
            GetScript  = { return @{ Result = "noop" } }
            SetScript  = {
                Invoke-Expression $using:Command
            }
            TestScript = { return $false }
        }
    }
}
InvokeCommand -Command $Command
