Configuration InvokeCommand {
    param (
        [String] $FilePath
    )
    
    Node "localhost" {
        Script WriteHostInfo {
            GetScript = { return @{ Result = "noop" } }
            SetScript = {
                hostname | Out-File -FilePath $using:FilePath -Append
                whoami   | Out-File -FilePath $using:FilePath -Append
            }
            TestScript = { return $false }
        }
    }
}
InvokeCommand -FilePath "C:\temp\owned.txt"
